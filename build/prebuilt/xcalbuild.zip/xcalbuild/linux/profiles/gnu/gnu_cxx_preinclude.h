// The two builtins not implemented by clang
// https://clang.llvm.org/docs/UsersManual.html#id57

int __builtin_va_arg_pack();
unsigned int __builtin_va_arg_pack_len();

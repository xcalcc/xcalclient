ARCHIVE_SECTION = ".staticx.archive"
INTERP_FILENAME = ".staticx.interp"
PROG_FILENAME   = ".staticx.prog"

MAX_INTERP_LEN = 256
MAX_RPATH_LEN = 256

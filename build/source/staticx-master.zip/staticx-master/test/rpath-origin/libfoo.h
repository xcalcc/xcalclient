#ifndef LIBFOO_DOT_H
#define LIBFOO_DOT_H

void foo_nop(void);

#endif /* LIBFOO_DOT_H */

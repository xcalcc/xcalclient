#include "libfoo.h"
#include "libbar.h"

void foo_nop(void)
{
    bar_nop();
}

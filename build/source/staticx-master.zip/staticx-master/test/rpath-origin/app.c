#include <stdio.h>
#include "libfoo.h"

int main(void)
{
    foo_nop();
    printf("Success\n");
    return 0;
}

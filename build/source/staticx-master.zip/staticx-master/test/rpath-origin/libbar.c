#include "libbar.h"

void bar_nop(void)
{
}

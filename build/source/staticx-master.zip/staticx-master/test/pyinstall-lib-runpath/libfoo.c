#include "libfoo.h"

int foo(void)
{
    return 42;
}

#include "libbar.h"

int bar(void)
{
    return 88;
}

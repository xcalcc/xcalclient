# This list originally had -dynamic variants, but that is not supported by staticx.
# See https://github.com/JonathonReinhart/staticx/issues/129#issuecomment-657246015
aux_apps = (
    'aux-glibc-static',
    'aux-musl-static',
)
